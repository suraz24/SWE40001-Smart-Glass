# gst-player
GStreamer Playback API

This repository only exists for historical reasons. GstPlayer is part of GStreamer since 1.8.0 and the example applications can now be found here:
https://cgit.freedesktop.org/gstreamer/gst-examples

Bugs or feature requests should be posted here:
https://bugzilla.gnome.org/enter_bug.cgi?product=GStreamer
